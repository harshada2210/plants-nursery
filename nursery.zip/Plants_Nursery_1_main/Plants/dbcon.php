<?php
$con=mysqli_connect('localhost','root',' ','plants nursery');
echo "connection is done";

if ($con==false)
{
echo "connection is  not done";
}

?>
